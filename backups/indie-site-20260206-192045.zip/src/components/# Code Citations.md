# Code Citations

## License: unknown
https://github.com/dipamsen/react-mui-starter/blob/268c7a10aa59dc7c58087531449b0517cbf7bdf9/index.html

```
.html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Your App</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
`
```


## License: MIT
https://github.com/marmelab/react-admin/blob/944b98d264588396644c8743e66169a1661d59b8/docs/Vite.md

```
.html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Your App</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
`
```


## License: MIT
https://github.com/alibaba/ice/blob/37c4278b13b1dbb19dfba174642f61f8be97da48/packages/vite-plugin-index-html/tests/index.test.ts

```
.html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Your App</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
`
```


## License: unknown
https://github.com/Quacken8/timey-wimey/blob/a890d6f72f9af875adbcf583d4d541133fac96c3/frontend/index.html

```
.html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Your App</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
`
```


## License: unknown
https://github.com/Ahmed-Magdy-Talaat/social-media-website/blob/b2d051ac6e39bce197252e6db7b689dc5f79fba8/index.html

```
.html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Your App</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
`
```


## License: MIT
https://github.com/marmelab/react-admin/blob/944b98d264588396644c8743e66169a1661d59b8/docs/Vite.md

```
.html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Your App</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
`
```


## License: MIT
https://github.com/alibaba/ice/blob/37c4278b13b1dbb19dfba174642f61f8be97da48/packages/vite-plugin-index-html/tests/index.test.ts

```
.html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Your App</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
`
```


## License: unknown
https://github.com/Quacken8/timey-wimey/blob/a890d6f72f9af875adbcf583d4d541133fac96c3/frontend/index.html

```
.html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Your App</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
`
```


## License: unknown
https://github.com/Ahmed-Magdy-Talaat/social-media-website/blob/b2d051ac6e39bce197252e6db7b689dc5f79fba8/index.html

```
.html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Your App</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
`
```


## License: unknown
https://github.com/dipamsen/react-mui-starter/blob/268c7a10aa59dc7c58087531449b0517cbf7bdf9/index.html

```
.html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Your App</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
`
```

